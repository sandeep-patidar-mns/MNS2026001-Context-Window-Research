# Deterministic Test Cases

These are software tests over a synthetic fixture, not research benchmark observations.

| ID | Test | Expected behavior | Result |
|---|---|---|---|
| TC-01 | Place gold evidence at beginning | Gold snippet S1 occurs before distractors | PASS |
| TC-02 | Place gold evidence in middle | Distractor S2 occurs before S1 and S1 before S3 | PASS |
| TC-03 | Place gold evidence at end | Distractors occur before gold snippet S1 | PASS |
| TC-04 | Build evidence-first prompt | Prompt explicitly asks for source IDs before answering | PASS |
| TC-05 | Parse valid JSON prediction | Extract answer and evidence IDs | PASS |
| TC-06 | Parse malformed JSON prediction | Preserve raw answer text; award no evidence IDs | PASS |
| TC-07 | Validate supplied task fixture | 3 records, 3 unique IDs, 0 schema/reference errors | PASS |

Execution command: `python -m unittest discover -s tests -v`

Recorded local execution: 7 tests passed. These tests do not invoke a language model.
