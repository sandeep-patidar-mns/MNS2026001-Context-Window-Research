import json, tempfile, unittest, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"src"))
from run_inference import render
from evaluate import parse_prediction, norm

class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.task={"task_id":"t1","question":"Which setting helped?",
          "snippets":[{"snippet_id":"S1","text":"Cache reduced time to 120 ms."},
                      {"snippet_id":"S2","text":"The interface was blue."},
                      {"snippet_id":"S3","text":"The test ran Tuesday."}],
          "gold_answer":"Cache reduced time to 120 ms.","gold_evidence_ids":["S1"]}
    def test_position_beginning(self):
        p=render(self.task,"direct","beginning")
        self.assertLess(p.index("[S1]"),p.index("[S2]"))
    def test_position_middle(self):
        p=render(self.task,"direct","middle")
        self.assertLess(p.index("[S2]"),p.index("[S1]"))
        self.assertLess(p.index("[S1]"),p.index("[S3]"))
    def test_position_end(self):
        p=render(self.task,"direct","end")
        self.assertLess(p.index("[S2]"),p.index("[S1]"))
    def test_evidence_first_instruction(self):
        p=render(self.task,"evidence_first","middle")
        self.assertIn("First identify the source IDs",p)
    def test_json_prediction_parse(self):
        answer,evidence=parse_prediction('{"answer":"Cache reduced time to 120 ms.","evidence_ids":["S1"]}')
        self.assertEqual(norm(answer),norm(self.task["gold_answer"]))
        self.assertEqual(evidence,{"S1"})
    def test_malformed_prediction_fallback(self):
        answer,evidence=parse_prediction("not json")
        self.assertEqual(answer,"not json")
        self.assertEqual(evidence,set())
    def test_task_validator_on_fixtures(self):
        r=subprocess.run([sys.executable,str(ROOT/"src/validate_tasks.py"),
          "--input",str(ROOT/"data/pilot_tasks.jsonl")],capture_output=True,text=True)
        self.assertEqual(r.returncode,0,r.stdout+r.stderr)
        self.assertIn("records=3 unique_ids=3 errors=0",r.stdout)

if __name__=="__main__": unittest.main()
