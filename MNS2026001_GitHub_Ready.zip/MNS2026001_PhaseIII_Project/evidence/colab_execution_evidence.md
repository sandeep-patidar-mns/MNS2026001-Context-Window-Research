# Colab execution evidence supplied by the user

This file transcribes outputs pasted by the user from their Google Colab session. It is not an independently generated run log. Preserve the user's original notebook output as the primary evidence when available.

## Prompt 08 — Environment diagnostic

```text
python_version: 3.13.16
platform: Linux-6.6.159+-x86_64-with-glibc2.39
torch_version: 2.11.0+cu130
torch_cuda_build: 13.0
cuda_available: True
gpu_count: 1
gpu_0_name: Tesla T4
gpu_0_total_memory_gib: 14.56
gpu_0_sanity_matmul: (512, 512) finite: True
transformers_installed: True
datasets_installed: True
accelerate_installed: True
bitsandbytes_installed: False
sentence_transformers_installed: True
diagnostic_complete: true
```

## Prompt 09 — Module 1 task schema validation

```text
validation_status: PASS
records_validated: 3
unique_task_ids: 3
note: schema validity does not establish label correctness or experimental results
Exit code: 0
```

## Module 2 — Variant generation

```text
variants_generated: 18
output_file: /content/phase3_extracted/MNS2026001_PhaseIII_Project/data/module2_context_variants.jsonl
variants_per_source_task: 6
context_sizes: [3, 15]
note: synthetic fixtures only; no model inference performed
```

## Module 2 — Schema validation

```text
validation_status: PASS
records_validated: 18
unique_task_ids: 18
note: schema validity does not establish label correctness or experimental results
exit_code: 0
```

## Module 2 — Position/consistency audit

```text
original_tasks: 3
generated_variants: 18
variants_per_source: {'toy_001': 6, 'toy_002': 6, 'toy_003': 6}
audit_status: PASS
errors: []
```

## Scope and limitations

- These are outputs pasted by the user in the conversation.
- The three underlying tasks are explicitly fictional synthetic fixtures.
- The 18 variants are derived from those three tasks and include manually authored fictional distractors.
- They are suitable only for pipeline/debugging unless the approved protocol explicitly permits such synthetic fixtures.
- They are not real research observations, do not constitute 18 independent tasks, and do not support scientific conclusions.
- No language-model inference has been reported as completed.
