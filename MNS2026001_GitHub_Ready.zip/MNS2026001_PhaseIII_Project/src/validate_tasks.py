#!/usr/bin/env python3
"""Validate task JSONL structure and evidence references; no model inference."""
import argparse, json
from pathlib import Path
REQUIRED={"task_id","question","snippets","gold_answer","gold_evidence_ids"}
def main():
 p=argparse.ArgumentParser(); p.add_argument("--input",default="data/pilot_tasks.jsonl"); a=p.parse_args()
 rows=[]; errors=[]; seen=set()
 for n,line in enumerate(Path(a.input).read_text(encoding="utf-8").splitlines(),1):
  if not line.strip(): continue
  try: x=json.loads(line)
  except Exception as e: errors.append(f"line {n}: invalid JSON: {e}"); continue
  miss=REQUIRED-set(x)
  if miss: errors.append(f"line {n}: missing {sorted(miss)}")
  tid=x.get("task_id")
  if tid in seen: errors.append(f"line {n}: duplicate task_id {tid}")
  seen.add(tid)
  ev={s.get("snippet_id") for s in x.get("snippets",[]) if isinstance(s,dict)}
  for eid in x.get("gold_evidence_ids",[]):
   if eid not in ev: errors.append(f"line {n}: evidence id {eid} absent from context")
  rows.append(x)
 print(f"records={len(rows)} unique_ids={len(seen)} errors={len(errors)}")
 for e in errors: print("ERROR:",e)
 raise SystemExit(1 if errors else 0)
if __name__=="__main__": main()
