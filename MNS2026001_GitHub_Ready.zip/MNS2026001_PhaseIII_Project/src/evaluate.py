#!/usr/bin/env python3
"""Evaluate saved model predictions; descriptive metrics only, no significance tests."""
import argparse, json, re, csv
from pathlib import Path

def norm(s):
    return " ".join(re.findall(r"\w+", (s or "").lower()))

def parse_prediction(raw):
    try:
        obj=json.loads(raw)
        if isinstance(obj, dict):
            return str(obj.get("answer","")), set(obj.get("evidence_ids", []))
    except Exception:
        pass
    return raw, set()

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--input",required=True)
    p.add_argument("--output",default="results/metrics.csv")
    a=p.parse_args()
    rows=[]; seen=set()
    for n,line in enumerate(Path(a.input).read_text(encoding="utf-8").splitlines(),1):
        if not line.strip(): continue
        x=json.loads(line)
        required={"task_id","mode","position","prediction_text","gold_answer","gold_evidence_ids"}
        missing=required-set(x)
        if missing: raise ValueError(f"line {n}: missing fields {sorted(missing)}")
        key=(x["task_id"],x["mode"],x["position"])
        if key in seen: raise ValueError(f"line {n}: duplicate prediction key {key}")
        seen.add(key)
        answer,pred_evidence=parse_prediction(x["prediction_text"])
        gold_evidence=set(x["gold_evidence_ids"])
        em=int(norm(answer)==norm(x["gold_answer"])) if norm(answer) else 0
        tp=len(pred_evidence & gold_evidence)
        precision=tp/len(pred_evidence) if pred_evidence else 0.0
        recall=tp/len(gold_evidence) if gold_evidence else 0.0
        f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
        rows.append({"task_id":x["task_id"],"mode":x["mode"],"position":x["position"],
          "normalized_exact_match":em,"evidence_precision":precision,"evidence_recall":recall,
          "evidence_f1":f1,"input_tokens":x.get("input_tokens"),
          "latency_seconds":x.get("latency_seconds")})
    if not rows: raise ValueError("No predictions found; refusing to create an empty result table.")
    Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    with open(a.output,"w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print(f"evaluated_rows={len(rows)} output={a.output}")

if __name__=="__main__": main()
