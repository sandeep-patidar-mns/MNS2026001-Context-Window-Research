#!/usr/bin/env python3
"""Local Hugging Face inference scaffold. Must be run and validated in Colab."""
import argparse, json, time, os
from pathlib import Path

def render(task, mode, position):
    snippets=list(task["snippets"])
    # Position control rotates the gold evidence snippet to a target region.
    gold=set(task.get("gold_evidence_ids",[]))
    evidence=[s for s in snippets if s.get("snippet_id") in gold]
    other=[s for s in snippets if s.get("snippet_id") not in gold]
    if evidence and position in {"beginning","middle","end"}:
        if position=="beginning": snippets=evidence+other
        elif position=="end": snippets=other+evidence
        else:
            mid=len(other)//2; snippets=other[:mid]+evidence+other[mid:]
    context="\n\n".join(f"[{s['snippet_id']}] {s['text']}" for s in snippets)
    if mode=="evidence_first":
        return ("Read the sources. First identify the source IDs that directly support an answer. "
                "Then answer the question using only those sources. Return JSON with keys "
                "answer and evidence_ids.\n\n"
                f"Question: {task['question']}\nSources:\n{context}")
    return ("Answer the question using the supplied sources. Return JSON with keys "
            "answer and evidence_ids.\n\n"
            f"Question: {task['question']}\nSources:\n{context}")

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--input",required=True); p.add_argument("--model",required=True)
    p.add_argument("--output",default="results/predictions.jsonl")
    p.add_argument("--max-new-tokens",type=int,default=160)
    p.add_argument("--modes",nargs="+",default=["direct","evidence_first"])
    p.add_argument("--positions",nargs="+",default=["beginning","middle","end"])
    a=p.parse_args()
    try:
        import torch
        from transformers import AutoTokenizer, AutoModelForCausalLM
    except ImportError as exc:
        raise SystemExit("Install requirements_candidate.txt in the Colab runtime before inference: " + str(exc))
    tok=AutoTokenizer.from_pretrained(a.model)
    model=AutoModelForCausalLM.from_pretrained(a.model,torch_dtype="auto",device_map="auto")
    model.eval(); Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    with open(a.input,encoding="utf-8") as f, open(a.output,"w",encoding="utf-8") as out:
      for line in f:
        if not line.strip(): continue
        task=json.loads(line)
        for mode in a.modes:
          for pos in a.positions:
            prompt=render(task,mode,pos)
            inputs=tok(prompt,return_tensors="pt").to(model.device)
            t0=time.perf_counter()
            with torch.no_grad():
              ids=model.generate(**inputs,max_new_tokens=a.max_new_tokens,do_sample=False)
            latency=time.perf_counter()-t0
            gen=ids[0][inputs["input_ids"].shape[1]:]
            pred=tok.decode(gen,skip_special_tokens=True)
            out.write(json.dumps({"task_id":task["task_id"],"mode":mode,"position":pos,
              "prediction_text":pred,"gold_answer":task["gold_answer"],
              "gold_evidence_ids":task["gold_evidence_ids"],
              "input_tokens":int(inputs["input_ids"].shape[1]),
              "latency_seconds":latency,"model":a.model},ensure_ascii=False)+"\n")
            out.flush()
if __name__=="__main__": main()
