# scripts

Add files only after the relevant stage is verified.
