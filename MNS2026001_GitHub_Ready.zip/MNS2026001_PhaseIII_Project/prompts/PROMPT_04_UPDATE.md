# Prompt 04 — Feasibility and novelty

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Free Google Colab T4, no paid API, one-week execution window. Prefer a compact open-weight instruction model that fits the T4; run a short feasibility smoke test before freezing it.

## Evidence boundary and remaining work
Go/no-go is conditional. Novelty is not established. Exact model, license, weights, tokenizer, VRAM footprint and benchmark access must be verified at execution. Fallback: use a smaller quantized/open model only if its license and runtime are checked; otherwise report a constrained protocol pilot.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
