# Prompt 06 — Dataset and comparator validation

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Retain the three fictional JSONL records solely as software fixtures. Actual evaluation requires 20 manually sourced, rights-checked research synthesis tasks with source text, gold answer, evidence IDs and source citations. Comparators: direct full-context answer; evidence-first then answer. Optional position control: same evidence reordered without changing content.

## Evidence boundary and remaining work
The 20-task set is not yet present. No official benchmark dataset, license or split is verified in this archive. Do not describe the fixture set as a research dataset. Use document-level separation if any source documents contribute multiple tasks; record provenance and avoid answer leakage in prompts.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
