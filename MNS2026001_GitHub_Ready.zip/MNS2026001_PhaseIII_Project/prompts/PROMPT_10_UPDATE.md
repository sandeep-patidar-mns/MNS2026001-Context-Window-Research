# Prompt 10 — Baseline reproduction and validation

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Baseline chosen for the pilot is direct-answer inference using one frozen open-weight model, with identical task/context inputs. Validation checklist compares tokenizer, prompt, decoding, truncation, task IDs, model revision and evaluation code.

## Evidence boundary and remaining work
No model outputs or published baseline replication are present. This prompt remains pending execution and comparison against a specific primary method.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
