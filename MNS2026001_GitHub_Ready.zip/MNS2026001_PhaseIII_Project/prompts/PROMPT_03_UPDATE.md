# Prompt 03 — Literature-to-experiment mapping

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Existing mapping covers Lost in the Middle, LongBench, NoLiMa and the context-length paper; proposed pilot uses evidence position and evidence-first prompting.

## Evidence boundary and remaining work
Bibliographic/high-level descriptions are recorded in the existing mapping. Full primary-method replication details, licenses, exact datasets and code/weights availability remain to be verified. The proposed study is a pilot design, not a reproduction.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
