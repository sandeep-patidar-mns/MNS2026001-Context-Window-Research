# Prompt 13 — Evaluation using real outputs

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Added evaluation script that checks task/condition identifiers, missing fields, duplicates and gold/prediction alignment; computes exact match, normalized exact match and evidence-ID precision/recall/F1 where annotations exist; exports CSV.

## Evidence boundary and remaining work
No actual predictions exist in the supplied notebook. Result tables must remain empty until raw model outputs are generated and audited. Statistical significance is not claimed.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
