# Prompt 17 — GitHub and reproducibility documentation

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Updated repository structure, README, environment test, task validator, inference/evaluation scaffolds, experiment config template, provenance and reproduction checklist are included in this package.

## Evidence boundary and remaining work
Commands marked [TEST REQUIRED] have not been executed in the supplied Colab evidence. No GitHub remote or authenticated GitHub connector is available in this session; files are prepared for push but not published.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
