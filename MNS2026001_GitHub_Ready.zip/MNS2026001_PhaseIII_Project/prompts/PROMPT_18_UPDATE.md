# Prompt 18 — Human-AI accountability

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Record actual AI-assisted tasks and human verification. Verified examples from this work: distinguishing snippet count from token count; refusing to treat synthetic fixtures as benchmark data; marking missing inference/results as pending rather than fabricating them.

## Evidence boundary and remaining work
These are documented review decisions from the available artifacts. Do not claim unobserved code commits, model corrections or experimental gains. Add exact prompts, diffs and future execution outcomes as they occur.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
