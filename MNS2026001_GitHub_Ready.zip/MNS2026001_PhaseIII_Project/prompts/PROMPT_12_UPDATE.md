# Prompt 12 — Contribution selection

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Use pathway B: a controlled comparison of direct answering and evidence-first answering across evidence position and token-defined context length. Keep the model fixed. Treat position and length as controlled factors.

## Evidence boundary and remaining work
This is a defensible pilot design, not a demonstrated novel contribution. Final choice is conditional on the baseline loading and a complete task set. No performance benefit is assumed.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
