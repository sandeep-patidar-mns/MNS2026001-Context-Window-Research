# Prompt 07 — Frozen experiment blueprint

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
Freeze task IDs and gold evidence before inference. Factors: evidence position (beginning/middle/end), context length defined by tokenizer token count, response procedure (direct/evidence-first). Same model checkpoint, tokenizer, decoding settings, task text and evaluation script across conditions. Save raw prompts, raw outputs, token counts, latency, seed, package versions and hardware.

## Evidence boundary and remaining work
Pilot design only. Context sizes must be token counts, not snippet counts. The existing [3,15] are snippet-count variants and cannot be relabeled as token lengths. Freeze primary metric and task split before model outputs are examined.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
