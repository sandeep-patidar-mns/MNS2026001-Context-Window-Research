# Prompt 05 — Research questions and success criteria

**Project:** Context-Window Degradation and Its Impact on Long-Document Research Synthesis  
**Student:** Sandeep Patidar | **Roll no.:** MNS2026001

## Current deliverable
RQ1: Under a fixed model and task set, does answer quality vary with evidence position (beginning, middle, end) and context length? RQ2: Does an evidence-first response procedure change answer correctness and supporting-evidence coverage relative to direct answering?

## Evidence boundary and remaining work
Primary outcomes: exact/normalized answer correctness and evidence-ID coverage, both computed from adjudicated gold labels. Secondary: input tokens and latency. No numerical success threshold is claimed before a pilot variance estimate. A result showing no consistent difference, or reversed direction, contradicts a degradation expectation.

## Status
**Prepared/updated:** 17 November 2026. This document records the current project state, not an assertion that all experiments have run. Update status only when the corresponding files, logs or results exist.
